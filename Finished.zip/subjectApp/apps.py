from django.apps import AppConfig


class SubjectappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'subjectApp'
