from django.apps import AppConfig


class AnnouncementappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'announcementApp'
